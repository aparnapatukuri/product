package com.niit.front.controller;

import org.slf4j.helpers.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.product.dao.ProductDAO;
import com.niit.product.model.Product;

public class ProductController {
private ProductDAO productDAO;
	

	@Autowired(required=true)
	@Qualifier(value="productDAO")
	public void setProductDAO(ProductDAO ps){
		this.productDAO = ps;
	}
	@RequestMapping("/")
	public String getLanding() 
	{
	    
		System.out.println("Index page called....");
	    return "index";
	}
	
	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public String listCategorys(Model model) { 
		model.addAttribute("product", new Product());
		model.addAttribute("productList", this.productDAO.list());
		return "category";
	}
	@RequestMapping(value= "/product/add", method = RequestMethod.POST)
	public String addCategory(@ModelAttribute("product") Product product){
		Util u =new Util();
		//int newName= u.replace(product.getId(), ",", "");
//		product.setId(newName);
	
		productDAO.saveOrUpdate(product);
		
		return "redirect:/products";
		
	}
	
	@RequestMapping("product/remove/{id}")
    public String removeCategory(@PathVariable("id") int id,ModelMap model) throws Exception{
		
       try {
    	   productDAO.delete(id);
		model.addAttribute("message","Successfully Added");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/products";
    }
 
	@RequestMapping("product/edit/{id}")
    public String editProduct(@PathVariable("id") int id, Model model){
    	System.out.println("editProduct");
        model.addAttribute("product", this.productDAO.getById(id));
        model.addAttribute("listCategorys", this.productDAO.list());
        return "category";
    }
}
