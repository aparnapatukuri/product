package com.niit.product;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.product.dao.ProductDAO;
import com.niit.product.model.Product;

public class PTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.product");
		context.refresh();
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

		Product product = (Product) context.getBean("product");
		product.setId(275);
		product.setName("mary");
		product.setDescription("jobs");
		
		productDAO.saveOrUpdate(product);
     	
		
	}
}
