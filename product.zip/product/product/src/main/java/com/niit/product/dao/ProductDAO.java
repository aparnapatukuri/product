package com.niit.product.dao;

import java.util.List;

import com.niit.product.model.Product;

public interface ProductDAO {
	public List<Product> list();

	public Product getById(int id);
	
	public Product getName(String name);

	public void saveOrUpdate(Product product);

	public void delete(int id);
}
